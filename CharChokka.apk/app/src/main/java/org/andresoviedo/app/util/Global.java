package org.andresoviedo.app.util;

public class Global {

    public static String currentWord = "";  //세부 정보를 보는 중인 단어
    public static String webUrl = "";
    public static String objUrl = "";
    public static CharChokkaJsonVO charChokka = null;

}
