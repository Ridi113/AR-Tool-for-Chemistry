package org.andresoviedo.android_3d_model_engine.services;

import org.andresoviedo.android_3d_model_engine.model.Object3DData;

public class LoadListenerAdapter implements LoadListener {

    @Override
    public void onStart() {

    }

    @Override
    public void onProgress(String progress) {

    }

    @Override
    public void onLoadError(Exception ex) {

    }

    @Override
    public void onLoad(Object3DData data) {

    }

    @Override
    public void onLoadComplete() {

    }
}
