package com.example.textrecognitionfromcamera;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MenuActivity extends AppCompatActivity {
    public static final int Go_TO_CAM1 = 201;
    public static final int Go_TO_CAM2 = 202;
    public static final String KEY_SAMPLE_DATA = "data";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button button1 = findViewById(R.id.bt1);
        Button button2 = findViewById(R.id.bt2);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra(String.valueOf(KEY_SAMPLE_DATA), "1");
                startActivityForResult(intent, Go_TO_CAM1);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra(String.valueOf(KEY_SAMPLE_DATA), "2");
                startActivityForResult(intent, Go_TO_CAM2);
            }
        });
    }
}