package com.example.textrecognitionfromcamera;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StringAdapter extends RecyclerView.Adapter<StringAdapter.ViewHolder> implements OnStringItemClickListener{
    ArrayList<String> items = new ArrayList<String>();
    OnStringItemClickListener listener;
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View itemView = inflater.inflate(R.layout.recycle_menu, viewGroup, false);


        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        String item = items.get(position);
        viewHolder.setItem(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        TextView textview;


        public ViewHolder(View itemView) {
            super(itemView);
            textview = itemView.findViewById(R.id.textview);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (listener != null ) {
                        listener.onItemClick(ViewHolder.this, v, position);
                    }
                }
            });
        }
        public void setItem(String item){
            textview.setText(item);
        }
    }
    public void addItem(String item){
        items.add(item);
    }
    public void setItems(ArrayList<String> items){
        this.items = items;
    }
    public String getItem(int position){
        return items.get(position);

    }
    public int getPosition(int position){
        return position;
    }
    public void setItem(int position, String item){
        items.set(position,item);
    }
    public void setOnItemClickListener(OnStringItemClickListener listener){
        this.listener = listener;
    }

    @Override
    public void onItemClick(ViewHolder holder, View v, int position){
        if (listener != null ) {
            listener.onItemClick(holder, v, position);
        }
    }
}
