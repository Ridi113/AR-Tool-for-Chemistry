package com.example.textrecognitionfromcamera;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;
import com.google.gson.Gson;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.cert.TrustAnchor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    SurfaceView cameraView;
    TextView textView;
    CameraSource cameraSource;
    DrawErr drawErr;
    final int RequestCameraPermissionID = 1001;
    private static final String FORMULA_FILE_NAME = "formula.txt"; private static final String REACTION_FILE_NAME = "reaction.txt";
    public static final int REQUEST_3D = 101;
    public static final int REQUEST_Web1 = 102;
    public static final int REQUEST_Web2 = 103;
    public static final String KEY_SAMPLE_DATA = "data";
    String nitem="";
    getApi ngpi;
    String dd;
    public static RequestQueue requestQueue;
    //Saves the detected bounding boxes of chosen words to an internal file /data/data/com.example.[projectname]/files
    //access the directory using Device File Explorer
    public void saveToFile(String text, String FILE_NAME){
        FileOutputStream fos = null;
        try {
            //text = text + "\n";
            fos = openFileOutput(FILE_NAME, MODE_APPEND);
            fos.write(text.getBytes());

            Log.i(text, getFilesDir()+"/"+FILE_NAME);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(fos != null){
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case RequestCameraPermissionID: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        return;
                    }
                    try {
                        cameraSource.start(cameraView.getHolder());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }
            break;
        }
    }

    public boolean isReaction(String string){
        if(string.contains("+") && string.contains("=")){
            Log.i("Equation Detected", "1011");
            return true;
        }
        return false;
    }

    public void printReactantProducts(String[] reactants, String[] products){
        Log.i("Reactions-function","Detected");
        for(String r: reactants){
            Log.i("reactants:", r);
        }

        for(String p: products){
            Log.i("products:", p);
        }
    }

    //Print a dictionary
    public void printDictionary(Hashtable<String, Integer> dictionary){
        Log.i("Printing", "Dictionary");

        for(String key : dictionary.keySet()) {

            int numberOfMolecules = dictionary.get(key);
            Log.i(key, Integer.toString(numberOfMolecules));
        }

    }
    //populates a dictionary with an element as the key and its respective molecule numbers as the value
    public Hashtable<String, Integer> populateDictionary(String[] elements){

        Hashtable<String, Integer> dictionary = new Hashtable<String, Integer>();

        String chemical = ""; int number_of_molecule = -1;
        for(String e:elements){
            if(e.length() != 0){
                Character ch = e.charAt(0);
                if( Character.isLetter(ch)){
                    number_of_molecule = 1;
                    chemical = e;
                }else if(Character.isDigit(ch)){
                    number_of_molecule = Integer.parseInt(String.valueOf(ch));
                    chemical = e.substring(1);

                }

                dictionary.put(chemical, number_of_molecule);
            }



        }


        return dictionary;
    }


    public String getStringRepresentation(ArrayList<Character> list)
    {
        StringBuilder builder = new StringBuilder(list.size());
        for(Character ch: list)
        {
            builder.append(ch);
        }
        return builder.toString();
    }

    // Function to remove non-alphanumeric
    // characters from string
    public static String removeNonAlphanumeric(String str)
    {
        // replace the given string
        // with empty string
        // except the pattern "[^a-zA-Z0-9]"
        str = str.replaceAll(
                "[^a-zA-Z0-9]", "");

        // return string
        return str;
    }

    public ArrayList<Hashtable<String, Integer>> elementAnalysisGenerator(Set<String> elements){
        ArrayList<Hashtable<String, Integer>>elementAnalysis = new ArrayList<Hashtable<String, Integer>>();
        for(String e: elements){
            Log.i("analysis", e);
            Hashtable<String, Integer>tempElement = new Hashtable<String, Integer>(); //key-element, value-number of atoms
            ArrayList<Character> elementCharacters = new ArrayList<Character>(); //tracks characters of element
            e = removeNonAlphanumeric(e);
            int indexOfElementString =0;
            int lengthOfElementString = e.length();

            while (indexOfElementString < lengthOfElementString){
                Character tempCh = e.charAt(indexOfElementString);
                if( Character.isLetter(tempCh)){
                    elementCharacters.add(tempCh);
                    if(indexOfElementString==lengthOfElementString-1){
                        String elementString = getStringRepresentation(elementCharacters);
                        Log.i("analysis of element", "102");
                        Log.i(elementString, Integer.toString(1));
                        tempElement.put(elementString, 1);
                        tempElement = new Hashtable<String, Integer>();
                        break;
                    }
                    indexOfElementString++;
                }
                else if(Character.isDigit(tempCh)){
                    String elementString = getStringRepresentation(elementCharacters);
                    Log.i("analysis of element", "101");
                    Log.i(elementString, String.valueOf(tempCh));
                    tempElement.put(elementString, Integer.parseInt(String.valueOf(tempCh)));
                    tempElement = new Hashtable<String, Integer>();
                    indexOfElementString++;
                }
            }
            elementAnalysis.add(tempElement);

        }

        return elementAnalysis;
    }

    public void printElementAnalysis(ArrayList<Hashtable<String, Integer>> listOfElements, Set<String> elements){
        int i = 0;
        /*for(String e:elements){
            Log.i("Length", Integer.toString(listOfElements.size()));
            Hashtable<String, Integer> elementsOfChemical = listOfElements.get(i ); i++;

            for(String key : elementsOfChemical.keySet()) {
                Log.i("i am here","yay");
                int numberOfMolecules = elementsOfChemical.get(key);
                Log.i(key, Integer.toString(numberOfMolecules));
            }

        }*/

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cameraView = (SurfaceView) findViewById(R.id.surface_view);
        textView = (TextView) findViewById(R.id.text_view);
        drawErr = findViewById(R.id.custom_view);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, true);
        recyclerView.setLayoutManager(layoutManager);
        StringAdapter adapter = new StringAdapter();

        adapter.addItem("View Information in Youtube");
        adapter.addItem("View Chemical Formula");
        adapter.addItem("View Moleculer Structure");

        recyclerView.setAdapter(adapter);
        Intent vintent = getIntent();
        int getintent = Integer.parseInt(processIntent(vintent));
        //Toast.makeText(getApplicationContext(), "아이템 선택됨: " + getintent, Toast.LENGTH_LONG).show();
        adapter.setOnItemClickListener(new OnStringItemClickListener() {
            @Override
            public void onItemClick(StringAdapter.ViewHolder holder, View view, int position) {
                int item = adapter.getPosition(position);
                //makeRequest();
                if ( item == 2 ) {
                    Intent intent = new Intent(getApplicationContext(), GltfActivity.class);
                    String data = ngpi.file;
                    //Toast.makeText(getApplicationContext(), "아이템 선택됨: " + data, Toast.LENGTH_LONG).show();
                    intent.putExtra(KEY_SAMPLE_DATA, data);
                    startActivityForResult(intent, REQUEST_3D);
                }
                else if ( item == 1 ) {
                    Intent intent = new Intent(getApplicationContext(), WebActivity.class);
                    String data = ngpi.wiki;
                    intent.putExtra(KEY_SAMPLE_DATA, data);
                    startActivityForResult(intent, REQUEST_Web1);
                }
                else if ( item == 0 ) {
                    Intent intent = new Intent(getApplicationContext(), Web2Activity.class);
                    String data = ngpi.youtube;
                    intent.putExtra(KEY_SAMPLE_DATA, data);
                    //Toast.makeText(getApplicationContext(), "아이템 선택됨: " + data, Toast.LENGTH_LONG).show();
                    startActivityForResult(intent, REQUEST_Web2);
                }
            }
        });


        TextRecognizer textRecognizer = new TextRecognizer.Builder(getApplicationContext()).build();
        if (!textRecognizer.isOperational()) {
            Log.w("MainActivity", "Detector dependencies are not yet available");
        }
        else {

            cameraSource = new CameraSource.Builder(getApplicationContext(), textRecognizer)
                    .setFacing(CameraSource.CAMERA_FACING_BACK)
                    .setRequestedPreviewSize(1280, 1024)
                    .setRequestedFps(2.0f)
                    .setAutoFocusEnabled(true)
                    .build();
            cameraView.getHolder().addCallback(new SurfaceHolder.Callback() {
                @Override
                public void surfaceCreated(SurfaceHolder surfaceHolder) {

                    try {
                        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {

                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[]{Manifest.permission.CAMERA},
                                    RequestCameraPermissionID);
                            return;
                        }
                        cameraSource.start(cameraView.getHolder());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

                }

                @Override
                public void surfaceDestroyed(SurfaceHolder surfaceHolder) {

                    cameraSource.stop();
                }
            });
            textRecognizer.setProcessor(new Detector.Processor<TextBlock>() {
                @Override
                public void release() {

                }

                @Override
                public void receiveDetections(Detector.Detections<TextBlock> detections) {

                    final SparseArray<TextBlock> items = detections.getDetectedItems();
                    final ArrayList<Rect> boundingBoxes = new ArrayList<Rect>();

                    if(items.size() != 0)
                    {
                        textView.post(new Runnable() {
                            @Override
                            public void run() {
                                StringBuilder stringBuilder = new StringBuilder();
                                
                                for(int i =0;i<items.size();++i)
                                {
                                    TextBlock item = items.valueAt(i);
                                    stringBuilder.append(item.getValue());
                                    stringBuilder.append("\n");

                                    Rect temp = item.getBoundingBox();
                                    //Log.i(temp.toString(), "R");

                                    //Separate the coordinates....
                                    String coordinates = temp.toString();
                                    String[] twoCoordinates = coordinates.split(" - ");
                                    String leftTop = twoCoordinates[0];String rightBottom = twoCoordinates[1];
                                    String[] firstCoordinate = leftTop.split(", ");
                                    String[] secondCoordinate = rightBottom.split(", ");
                                    String left = firstCoordinate[0].split("\\(")[1]; String top = firstCoordinate[1];

                                    String right = secondCoordinate[0]; String bottom = secondCoordinate[1].split("\\)")[0];
                                    Log.i(left, top); Log.i(right, bottom);

                                    String tempString = stringBuilder.toString();
                                    Log.i(tempString, "00");

                                    String toDetect = item.getValue().toLowerCase();
                                    /*boolean condition1 = toDetect.contains("water") || toDetect.contains("sulfuric acid");
                                    boolean condition2 = toDetect.contains("h2o") || toDetect.contains("h20");
                                    boolean condition3 = toDetect.contains("h2so4") || toDetect.contains("h2504") || toDetect.contains("h25o4") || toDetect.contains("h2s04");
*/
                                    //List of key-words to detect
                                    String[] listOfWords = {"water", "sulfuric acid", "h2o", "h20", "h2so4",  "h2504", "h25o4","h2s04" };
                                    //Finding the key-word's coordinates
                                    int left_position = Integer.parseInt(left);
                                    int right_position = Integer.parseInt(right);
                                    int lengthOfDetectedString = toDetect.length();
                                    int span = right_position-left_position;
                                    int perCharacterSpace = (int)(span/lengthOfDetectedString);

                                    //composition of h2o reaction
                                    Hashtable<String, Integer> idealReactant = new Hashtable<String, Integer>() {{
                                        put("h2", 2);
                                        put("o2", 1);
                                        //etc
                                    }};

                                    Hashtable<String, Integer> idealProduct = new Hashtable<String, Integer>() {{
                                        put("h2o", 2);
                                        //etc
                                    }};



                                    if(getintent == 2 && isReaction(toDetect)){
                                        if (!DrawErr.ShapeList.isEmpty()) {
                                            DrawErr.ShapeList.clear();
                                        }
                                        toDetect = toDetect.replaceAll("\\s+","");
                                        toDetect = toDetect.replaceAll("0", "o");
                                        String[] reactantProduct = toDetect.split("=");
                                        String reactant = reactantProduct[0]; String product = reactantProduct[1];
                                        String[] reactants = reactant.split("\\+"); //saves all reactants
                                        String[] products = product.split("\\+"); //saves all products

                                        // creating a My HashTable Dictionary
                                        Hashtable<String, Integer> reactantNumber = new Hashtable<String, Integer>();
                                        Hashtable<String, Integer> productNumber = new Hashtable<String, Integer>();

                                        //printReactantProducts(reactants, products); //Print all the detected reactants and products

                                        reactantNumber = populateDictionary(reactants);
                                        productNumber = populateDictionary(products);

                                        printDictionary(reactantNumber);
                                        printDictionary(productNumber);

                                        //Match with ideal reaction formulation to find errors in reactions
                                        boolean matched = true;
                                        for(String r:reactantNumber.keySet()){
                                            if(idealReactant.containsKey(r) ==false){
                                                matched =false;
                                                Log.i("Mismatch Found", r);

                                                int startIndex = toDetect.indexOf(r);
                                                int newLeft = perCharacterSpace*startIndex + left_position;
                                                int newRight = newLeft + r.length()*perCharacterSpace;
                                                String coord = top +","+ Integer.toString(newLeft)+"-"+bottom+","+Integer.toString(newRight);

                                                Log.i("Wrong Reactant", coord);

                                                String tempStrToSave =  r+":"+coord+"\n";
                                                Paint npaint = new Paint();

                                                drawErr.setVisibility(View.VISIBLE);
                                                npaint.setColor(Color.RED);
                                                DrawErr.MyShape newshp = new DrawErr.MyShape(newLeft, Float.valueOf(top), newRight,Float.valueOf(bottom), npaint, r);
                                                DrawErr.UpdateShape(newshp);

                                                saveToFile(tempStrToSave, REACTION_FILE_NAME);


                                            }else{
                                                int detectedNumber = reactantNumber.get(r);
                                                int idealNumber = idealReactant.get(r);
                                                if(detectedNumber != idealNumber){
                                                    matched= false;

                                                    String tempChemical = Integer.toString(detectedNumber)+r;
                                                    Log.i("Mismatch Found", tempChemical);

                                                    int startIndex = toDetect.indexOf(tempChemical);
                                                    int newLeft = perCharacterSpace*startIndex + left_position;
                                                    int newRight = newLeft + tempChemical.length()*perCharacterSpace;
                                                    String coord = top +","+ Integer.toString(newLeft)+"-"+bottom+","+Integer.toString(newRight);

                                                    Log.i("Wrong Reactant Mole no.", coord);
                                                    Paint npaint = new Paint();

                                                    drawErr.setVisibility(View.VISIBLE);
                                                    npaint.setColor(Color.RED);
                                                    DrawErr.MyShape newshp = new DrawErr.MyShape(newLeft, Float.valueOf(top), newRight,Float.valueOf(bottom), npaint, r);
                                                    DrawErr.UpdateShape(newshp);


                                                    String tempStrToSave =  tempChemical+":"+coord+"\n";

                                                    saveToFile(tempStrToSave, REACTION_FILE_NAME);
                                                }
                                            }
                                        }
                                        if(matched){
                                            for(String p:productNumber.keySet()){
                                                if(idealProduct.containsKey(p)==false){
                                                    matched=false;
                                                    Log.i("Mismatch Found", p);

                                                    int startIndex = toDetect.indexOf(p);
                                                    int newLeft = perCharacterSpace*startIndex + left_position;
                                                    int newRight = newLeft + p.length()*perCharacterSpace;
                                                    String coord = top +","+ Integer.toString(newLeft)+"-"+bottom+","+Integer.toString(newRight);

                                                    // 추가
                                                    //////////////////
                                                    Paint npaint = new Paint();
                                                    drawErr.setVisibility(View.VISIBLE);
                                                    npaint.setColor(Color.RED);
                                                    DrawErr.MyShape newshp = new DrawErr.MyShape(newLeft, Float.valueOf(top), newRight,Float.valueOf(bottom), npaint, p);
                                                    DrawErr.UpdateShape(newshp);

                                                    Log.i("Wrong Product", coord);

                                                    String tempStrToSave =  p+":"+coord+"\n";

                                                    saveToFile(tempStrToSave, REACTION_FILE_NAME);
                                                }else{
                                                    int detectedNumber = productNumber.get(p);
                                                    int idealNumber = idealProduct.get(p);
                                                    if(detectedNumber != idealNumber){
                                                        matched= false;
                                                        String tempChemical = Integer.toString(detectedNumber)+p;
                                                        Log.i("Mismatch Found", tempChemical);


                                                        Log.i("Mismatch Found", tempChemical);

                                                        int startIndex = toDetect.indexOf(tempChemical);
                                                        int newLeft = perCharacterSpace*startIndex + left_position;
                                                        int newRight = newLeft + tempChemical.length()*perCharacterSpace;
                                                        String coord = top +","+ Integer.toString(newLeft)+"-"+bottom+","+Integer.toString(newRight);
                                                        //////////////////
                                                        Paint npaint = new Paint();
                                                        drawErr.setVisibility(View.VISIBLE);
                                                        npaint.setColor(Color.GREEN);
                                                        DrawErr.MyShape newshp = new DrawErr.MyShape(newLeft, Float.valueOf(top), newRight,Float.valueOf(bottom), npaint, p);
                                                        DrawErr.UpdateShape(newshp);
                                                        Log.i("Wrong Product Mole no.", coord);

                                                        String tempStrToSave =  tempChemical+":"+coord+"\n";

                                                        saveToFile(tempStrToSave, REACTION_FILE_NAME);

                                                    }
                                                }
                                            }
                                        }
                                        if(matched){
                                            Log.i("Results","Matched");
                                            Paint npaint = new Paint();
                                            drawErr.setVisibility(View.VISIBLE);
                                            npaint.setColor(Color.WHITE);
                                            DrawErr.MyShape newshp = new DrawErr.MyShape(Float.valueOf(left)-50.0f, Float.valueOf(top)-50.0f, Float.valueOf(right)+10.0f,Float.valueOf(bottom)+50.0f, npaint, "entire");
                                            DrawErr.UpdateShape(newshp);
                                            drawErr.invalidate();
                                        }
                                        else{
                                            Log.i("Results","DId NOT match");
                                            drawErr.setVisibility(View.VISIBLE);
                                            Paint npaint = new Paint();
                                            npaint.setColor(Color.WHITE);
                                            DrawErr.MyShape newshp = new DrawErr.MyShape(Float.valueOf(left)-50.0f, Float.valueOf(top)-50.0f, Float.valueOf(right)+10.0f,Float.valueOf(bottom)+50.0f, npaint, "entire");
                                            DrawErr.UpdateShape(newshp);
                                            drawErr.invalidate();
                                        }



                                        /*ArrayList<Hashtable<String, Integer> > reactantElementAnalysis = new ArrayList<Hashtable<String, Integer>>();
                                        ArrayList<Hashtable<String, Integer> > productElementAnalysis = new ArrayList<Hashtable<String, Integer>>();

                                        reactantElementAnalysis = elementAnalysisGenerator(reactantNumber.keySet());
                                        productElementAnalysis = elementAnalysisGenerator(productNumber.keySet());

                                        printElementAnalysis(reactantElementAnalysis, reactantNumber.keySet());
                                        printElementAnalysis(productElementAnalysis, productNumber.keySet());*/





                                    }else if (getintent == 1){
                                        //Detect if a key-word is present
                                        boolean found = false;
                                        String foundWord = "";
                                        for (String keyWord: listOfWords){
                                            if(toDetect.contains(keyWord)){
                                                found = true;
                                                foundWord = keyWord;
                                                break;
                                            }
                                        }


                                        //If a keyword is found detect its bounding box and save it to a file
                                        if(found){

                                            if (!DrawErr.ShapeList.isEmpty()) {
                                                DrawErr.ShapeList.clear();
                                            }

                                            int startIndex = toDetect.indexOf(foundWord);
                                            int newLeft = perCharacterSpace*startIndex + left_position;
                                            int newRight = newLeft + lengthOfDetectedString*perCharacterSpace;

                                            String coord = top +","+ Integer.toString(newLeft)+"-"+bottom+","+Integer.toString(newRight);
                                            String stringToSend = foundWord+": "+coord+"\n";
                                            //////////////////
                                            Paint npaint = new Paint();
                                            drawErr.setVisibility(View.VISIBLE);
                                            npaint.setColor(Color.rgb(0xff,0x7f,0x00));
                                            DrawErr.MyShape newshp = new DrawErr.MyShape(newLeft, Float.valueOf(top), newRight,Float.valueOf(bottom), npaint, foundWord);
                                            DrawErr.UpdateShape(newshp);
                                            drawErr.invalidate();
                                            //////////////////
                                            saveToFile(stringToSend, FORMULA_FILE_NAME);
                                        }


                                    }


                                    /*if(condition1 || condition2 || condition3){
                                        Log.i("0"," Paisi!!!! <3");
                                        boundingBoxes.add(temp);
                                        String boundingBox =temp.toString();
                                        int lengthBoundingBox = boundingBox.length();
                                        String coords = boundingBox.substring(5, lengthBoundingBox-1);


                                        String stringToSend = toDetect+":"+coords+"\n";
                                        saveToFile(stringToSend);

                                    }*/


                                }
                                //textView.setText(stringBuilder.toString());
                            }
                        });
                    }
                }
            });
        }
    }

    private String processIntent(Intent vintent) {
        String data="";
        if ( vintent != null ) {
            Bundle bundle = vintent.getExtras();
            data= bundle.getString(KEY_SAMPLE_DATA);
        }
        return data;
    }

    private void makeRequest() {
        String nurl = "http://27.255.81.126:5050/contents/update/1";
        StringRequest request = new StringRequest(Request.Method.GET, nurl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //Log.i("5", "printno");
                processResponse(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params  = new HashMap<String, String>();
                return params;
            }
        };
        request.setShouldCache(false);
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
    public void processResponse(String response){
        Gson gson = new Gson();
        getApi gpi = gson.fromJson(response, getApi.class);
        ngpi = new getApi(gpi.id, gpi.name, gpi.formula, gpi.description, gpi.wiki, gpi.youtube, gpi.file);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float tx = event.getX();
        float ty = event.getY();
        if ( event.getAction() == MotionEvent.ACTION_DOWN ) {
            for ( DrawErr.MyShape cshape : DrawErr.ShapeList ) {
                if ( (cshape.startX < tx) && (cshape.stopX > tx) && (cshape.startY < ty) && (cshape.stopY > ty) ) {
                    LinearLayout linearLayout = findViewById(R.id.recycle);
                    linearLayout.setVisibility(View.VISIBLE);
                    nitem = drawErr.toupdate;
                    makeRequest();
                    break;
                }
            }

        }
        return true;
    }


}