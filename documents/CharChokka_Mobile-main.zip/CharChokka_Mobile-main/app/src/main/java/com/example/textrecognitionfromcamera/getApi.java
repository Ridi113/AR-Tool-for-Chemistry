package com.example.textrecognitionfromcamera;

public class getApi {
    String id;
    String name;
    String formula;
    String description;
    String wiki;
    String youtube;
    String file;

    public getApi(String id, String name, String formula, String description, String wiki, String youtube, String file) {
        this.id = id;
        this.name = name;
        this.formula = formula;
        this.description = description;
        this.wiki = wiki;
        this.youtube = youtube;
        this.file = file;
    }
}