package com.example.textrecognitionfromcamera;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;

class Point{
    float x;
    float y;

    public Point(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
public class DrawErr extends View {

    private static Paint paint;
    ArrayList<Point> arp;
    MyShape curShape;
    static ArrayList<MyShape> ShapeList = new ArrayList<MyShape>();
    String toupdate = "";
    public DrawErr(Context context) {
        super(context);
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arp = new ArrayList<Point>();
    }

    public DrawErr(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arp = new ArrayList<Point>();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        //int i = 0;
        for (MyShape cshape : ShapeList){
        //    i++;
        //    Log.i("1", "msg :" + i);
            draw_shape(cshape, canvas);
        }
    }
    @Override
    public boolean onTouchEvent(MotionEvent event){
        if ( event.getAction() == MotionEvent.ACTION_DOWN ) {
            float tx = event.getX();
            float ty = event.getY();

            for ( MyShape cshape : ShapeList ) {
                if ( (cshape.startX < tx) && (cshape.stopX > tx) && (cshape.startY < ty) && (cshape.stopY > ty) ) {
                    toupdate = cshape.word;
                }
            }
        }
        return false;
    }

    public void draw_shape(MyShape myShape, Canvas canvas){

        Path path = new Path();
        path.moveTo(myShape.startX, myShape.startY);
        path.lineTo(myShape.startX, myShape.stopY);
        path.lineTo(myShape.stopX, myShape.stopY);
        path.lineTo(myShape.stopX, myShape.startY);
        path.close();
        canvas.drawPath(path, myShape.paint);

    }
    public static void UpdateShape(MyShape myShape){
        myShape.paint.setStrokeWidth(5f);
        myShape.paint.setStyle(Paint.Style.STROKE);
        float ScalingY1 = -120 +  myShape.startY / 1280 * 2019;
        float ScalingY2 = -80 + myShape.stopY / 1280 * 2019;
        float ScalingX1 = -50 + myShape.startX / 1024 * 1080;
        float ScalingX2 = myShape.stopX / 1024 * 1080;
        MyShape newtmp = new MyShape(ScalingX1, ScalingY1, ScalingX2, ScalingY2, myShape.paint, myShape.word);
        ShapeList.add(newtmp);
    }
    public static class MyShape {

        float startX, startY, stopX, stopY;
        Paint paint;
        String word;

        public MyShape( float startX, float startY, float stopX, float stopY, Paint paint , String word) {
            this.paint = paint;
            this.startX = startX;
            this.startY = startY;
            this.stopX = stopX;
            this.stopY = stopY;
            this.paint = paint;
            this.word = word;

        }
    }
}
