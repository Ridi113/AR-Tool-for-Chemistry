package com.example.textrecognitionfromcamera;

import android.view.View;

public interface OnStringItemClickListener {
    public void onItemClick(StringAdapter.ViewHolder holder, View view, int position);

}
